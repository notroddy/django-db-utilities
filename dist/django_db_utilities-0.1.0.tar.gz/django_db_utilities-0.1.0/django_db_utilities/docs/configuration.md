# Configuration

To configure `django-db-utilities`, add it to your `INSTALLED_APPS` in your Django settings:

```python
INSTALLED_APPS = [
    # ...existing apps...
    'django_db_utilities',
]
```