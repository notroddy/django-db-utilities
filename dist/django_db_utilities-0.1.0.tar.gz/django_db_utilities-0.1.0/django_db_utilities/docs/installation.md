# Installation

To install the `django-db-utilities` library, use pip:

```bash
pip install django-db-utilities
```